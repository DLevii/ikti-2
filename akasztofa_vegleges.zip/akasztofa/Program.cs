﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Akasztofa
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> szavak = new List<string>()
            {
                "alma", "banan", "citrom", "eper", "szilva", "barack", "dio", "korte", "mango", "narancs",
                "ananasz", "kiwi", "avokado", "cseresznye", "malna", "ribizli", "szeder", "grapefruit", "papaya", "kokusz",
                "szamoca", "dinny", "mandula", "gesztenye", "meggy", "datolya", "fuge", "lime", "pomelo", "maracuja",
                "auto", "motor", "vonat", "repulo", "bicikli", "busz", "hajo", "tank", "traktor", "roller",
                "asztal", "szek", "lampa", "ajto", "ablak", "fotel", "szonyeg", "kanape", "tukor", "polc",
                "kutya", "macska", "madar", "hal", "lo", "tigris", "oroszlan", "zebra", "gepard", "panda",
                "tenger", "hegy", "folyo", "to", "varos", "falu", "haz", "kastely", "sziget", "barlang",
                "foci", "kosar", "tenisz", "sakk", "golf", "pingpong", "birkozas", "torna", "roplabda", "vizilabda",
                "hinta", "ugralo", "korcsolya", "sieles", "uszas", "futas", "tura", "kirandulas", "horgaszat", "vadaszat",
                "zenekar", "gitar", "dob", "zongora", "fuvola", "hegedu", "trombita", "klarinet", "szaxofon", "csello"
            };

            Random rand = new Random();
            string szo = szavak[rand.Next(szavak.Count)].ToUpper();
            char[] talalat = new string('_', szo.Length).ToCharArray();
            HashSet<char> tippeltBetuk = new HashSet<char>();

            int hibak = 0;
            const int maxHibak = 11;

            while (hibak < maxHibak && new string(talalat) != szo)
            {
                Console.Clear();
                Console.WriteLine("=== AKASZTÓFA ===\n");
                Rajzol(hibak);
                Console.WriteLine($"\nSzó: {string.Join(" ", talalat)}");
                Console.WriteLine($"Tippelt betűk: {string.Join(", ", tippeltBetuk)}");
                Console.WriteLine($"\nHátralévő életek: {maxHibak - hibak}");
                Console.Write("\nAdj meg egy betűt: ");
                string input = Console.ReadLine().ToUpper();

                if (string.IsNullOrWhiteSpace(input) || input.Length != 1)
                {
                    Console.WriteLine("❗ Kérlek, egy betűt adj meg!");
                    Console.ReadKey();
                    continue;
                }

                char betu = input[0];
                if (tippeltBetuk.Contains(betu))
                {
                    Console.WriteLine("❗ Ezt a betűt már tippelted!");
                    Console.ReadKey();
                    continue;
                }

                tippeltBetuk.Add(betu);

                if (szo.Contains(betu))
                {
                    for (int i = 0; i < szo.Length; i++)
                    {
                        if (szo[i] == betu)
                            talalat[i] = betu;
                    }
                }
                else
                {
                    hibak++;
                }
            }

            Console.Clear();
            Rajzol(hibak);
            if (new string(talalat) == szo)
            {
                Console.WriteLine($"\n🎉 Gratulálok, kitaláltad a szót: {szo}!");
            }
            else
            {
                Console.WriteLine($"\n💀 Vége a játéknak! A szó ez volt: {szo}");
            }

            Console.WriteLine("\nNyomj meg egy gombot a kilépéshez...");
            Console.ReadKey();
        }

        static void Rajzol(int hibak)
        {
            string[] figura = new string[12];
            figura[0] =
@" 
  +---+
      |
      |
      |
      |
      |
=========";

            figura[1] =
@" 
  +---+
  |   |
      |
      |
      |
      |
=========";

            figura[2] =
@" 
  +---+
  |   |
  O   |
      |
      |
      |
=========";

            figura[3] =
@" 
  +---+
  |   |
  O   |
  |   |
      |
      |
=========";

            figura[4] =
@" 
  +---+
  |   |
  O   |
 /|   |
      |
      |
=========";

            figura[5] =
@" 
  +---+
  |   |
  O   |
 /|\  |
      |
      |
=========";

            figura[6] =
@" 
  +---+
  |   |
  O   |
 /|\  |
 /    |
      |
=========";

            figura[7] =
@" 
  +---+
  |   |
  O   |
 /|\  |
 / \  |
      |
=========";

            figura[8] =
@" 
  +---+
  |   |
 [O   |
 /|\  |
 / \  |
      |
=========";

            figura[9] =
@" 
  +---+
  |   |
 [O]  |
 /|\  |
 / \  |
      |
=========";

            figura[10] =
@" 
  +---+
  |   |
 [O]  |
 /|\  |
_/ \_ |
      |
=========";

            figura[11] =
@" 
  +---+
  |   |
 [O]  |
 /|\  |
_/ \_ |
 RIP  |
=========";

            Console.WriteLine(figura[Math.Min(hibak, figura.Length - 1)]);
        }
    }
}
